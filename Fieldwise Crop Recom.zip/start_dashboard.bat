@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo Project environment is missing.
    echo Run these commands from this folder first:
    echo   py -3.10 -m venv .venv
    echo   .venv\Scripts\python.exe -m pip install -r requirements.txt
    pause
    exit /b 1
)

echo Starting Smart Crop dashboard at http://localhost:8000
echo Keep this window open while using the dashboard. Press Ctrl+C to stop.
".venv\Scripts\python.exe" -u web_app.py
pause
